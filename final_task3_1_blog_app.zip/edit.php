<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$id = $_GET['id'];
$stmt = $conn->prepare('SELECT title, content FROM posts WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->bind_result($title, $content);
$stmt->fetch();
$stmt->close();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $newtitle = $_POST['title'];
  $newcontent = $_POST['content'];
  $update = $conn->prepare('UPDATE posts SET title = ?, content = ? WHERE id = ?');
  $update->bind_param('ssi', $newtitle, $newcontent, $id);
  $update->execute();
  header('Location: dashboard.php');
}
?>
<!DOCTYPE html><html><head><title>Edit</title><link rel='stylesheet' href='style.css'></head><body>
<form method='POST'><input name='title' value="<?= $title ?>"><textarea name='content'><?= $content ?></textarea><button>Update</button></form>
</body></html>