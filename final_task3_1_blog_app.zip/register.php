<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $confirm = $_POST['confirm_password'];
  if ($password !== $confirm) die('Passwords do not match');
  $hash = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $conn->prepare('INSERT INTO users (username, password) VALUES (?, ?)');
  $stmt->bind_param('ss', $username, $hash);
  $stmt->execute();
  echo 'Registered successfully. <a href="index.php">Login</a>';
}
?>