<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
include 'db.php';

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;
$search = isset($_GET['search']) ? $_GET['search'] : '';
$searchParam = "%{$search}%";

if (!empty($search)) {
    $stmt = $conn->prepare("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id WHERE title LIKE ? OR content LIKE ? ORDER BY created_at DESC LIMIT ?, ?");
    $stmt->bind_param("ssii", $searchParam, $searchParam, $start, $limit);
} else {
    $stmt = $conn->prepare("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id ORDER BY created_at DESC LIMIT ?, ?");
    $stmt->bind_param("ii", $start, $limit);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>

  <div class="links">
    <a href="create.php">Create New Post</a> |
    <a href="logout.php">Logout</a>
  </div>

  <form method="GET" action="dashboard.php" style="text-align:center;">
    <input type="text" name="search" placeholder="Search posts..." value="<?= htmlspecialchars($search) ?>" required>
    <button type="submit">Search</button>
  </form>

  <h3>All Posts</h3>
  <?php while ($row = $result->fetch_assoc()): ?>
    <?php
    $title = $row['title'];
    $content = $row['content'];
    if (!empty($search)) {
        $title = str_ireplace($search, "<mark>$search</mark>", $title);
        $content = str_ireplace($search, "<mark>$search</mark>", $content);
    }
    ?>
    <div class="post-card">
        <strong><?= $title ?></strong><br>
        <small>By <?= htmlspecialchars($row['username']) ?></small><br><br>
        <?= nl2br($content) ?><br><br>
        <?php if ($row['user_id'] == $_SESSION['user_id']): ?>
            <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
            <a href="delete.php?id=<?= $row['id'] ?>">Delete</a>
        <?php endif; ?>
    </div>
  <?php endwhile; ?>

  <?php
  $countQuery = "SELECT COUNT(*) AS total FROM posts";
  if (!empty($search)) {
      $searchEscaped = $conn->real_escape_string($search);
      $countQuery = "SELECT COUNT(*) AS total FROM posts WHERE title LIKE '%$searchEscaped%' OR content LIKE '%$searchEscaped%'";
  }
  $totalResult = $conn->query($countQuery);
  $totalRow = $totalResult->fetch_assoc();
  $totalPosts = $totalRow['total'];
  $totalPages = ceil($totalPosts / $limit);
  ?>

  <div class="pagination" style="text-align:center; margin-top:20px;">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
      <a href="?page=<?= $i ?>&search=<?= htmlspecialchars($search) ?>" style="margin: 0 5px;">
        <?= ($i == $page) ? "<strong>$i</strong>" : $i ?>
      </a>
    <?php endfor; ?>
  </div>
</body>
</html>