<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $title = $_POST['title'];
  $content = $_POST['content'];
  $uid = $_SESSION['user_id'];
  $stmt = $conn->prepare('INSERT INTO posts (title, content, user_id) VALUES (?, ?, ?)');
  $stmt->bind_param('ssi', $title, $content, $uid);
  $stmt->execute();
  header('Location: dashboard.php');
}
?>
<!DOCTYPE html><html><head><title>Create</title><link rel='stylesheet' href='style.css'></head><body>
<form method='POST'><input name='title' placeholder='Title'><textarea name='content' placeholder='Content'></textarea><button>Submit</button></form>
</body></html>